#!/bin/bash


declare -a fileSystemDirectoryList=("/var/log/hadoop/hdfs/")

for i in "${fileSystemDirectoryList[@]}"
do
    echo "Cleaning up $i ..."

    find ${i} -type f -mtime +90 -exec rm -rf {} \;
done
