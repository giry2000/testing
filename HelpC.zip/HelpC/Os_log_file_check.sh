#!/bin/bash

#ADMIN="giri.nadarajah@cn.ca"
ADMIN="giri.nadarajah@cn.ca,ananthan.kathiramalai@cn.ca,mahammad.fareedShaik@cn.ca, kavyasree.ponne@cn.ca"

N=90


declare -a fileSystemDirectoryList=("/var/log/hadoop/")

for i in "${fileSystemDirectoryList[@]}"
do
    echo "Checking up more $N days old files  $i ..."

    find ${i} -type f -mtime +$N -exec ls -larth {}  \; > /hadoop/`hostname`_MoreThan90Days.txt

    mail -s "  ****More than $N Days log files from /var/log/hadoop/ ******** " -a "/hadoop/`hostname`_MoreThan90Days.txt"  $ADMIN  < "/hadoop/`hostname`_MoreThan90Days.txt"
done
