#!/bin/bash


declare -a fileSystemDirectoryList=("/hadoop/log/hadoop/hdfs/" "/hadoop/log/knox/" "/hadoop/log/hive/" "/hadoop/log/atlas/" "/hadoop/log/ambari-infra-solr" "/hadoop/log/ambari-server")

for i in "${fileSystemDirectoryList[@]}"
do
    echo "Cleaning up $i ..."

    find ${i} -type f -mtime +90 -exec rm -rf {} \;
done

