#!/bin/sh
# Shell script to monitor or watch the disk space
# It will send an email to $ADMIN, if the (free avilable) percentage
# of space is >= 90%
# -------------------------------------------------------------------------
# set admin email so that you can get email
#ADMIN="giri.nadarajah@mercer.com"
ADMIN="Justin.Ng@mercer.com,giri.nadarajah@mercer.com,nitin.saini@mercer.com"
# set alert level 90% is default
ALERT=85
df -H | grep -vE '^Filesystem|tmpfs|cdrom' | awk '{ print $5 " " $1 "  " $6}' | while read output;
do
  #echo $output
  usep=$(echo $output | awk '{ print $1 }' | cut -d'%' -f1  )
  partition=$(echo $output | awk '{ print $2 }' )
  apath=$(echo $output | awk '{ print $3 }' )
  if [ $usep -ge $ALERT ]; then
    echo "Running out of space \"$partition    $apath  ($usep%)\" on $(hostname) as on $(date)" |
     mail -s "Alert: $apath  Almost out of disk space ($usep%) on $(hostname)" $ADMIN
  fi
done

