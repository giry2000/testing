#!/bin/bash
#DB_BACKUP="/hadoop/backup/ambari_backup/`date +%Y-%m-%d`"
#mkdir -p $DB_BACKUP
#pg_dump -U ambari -f "$DB_BACKUP/ambari_dump_before_stop_`date +%Y-%m-%d`"
#gzip "$DB_BACKUP/ambari_dump_before_stop_`date +%Y-%m-%d`"
#cp /etc/ambari-server/conf/ambari.properties "$DB_BACKUP/ambari.properties_before_stop_`date +%Y-%m-%d`"
#cp /etc/ambari-agent/conf/ambari-agent.ini "$DB_BACKUP/ambari-agent.ini_before_stop_`date +%Y-%m-%d`"
#find /hadoop/backup/ambari_backup/ -maxdepth 1 -type d -mtime +10 -exec rm -rf {} \;

#kinit -kt /etc/security/keytabs/hdfs.headless.keytab hdfs-MMCHDP@CORP.MMCO.INT

#hdfs dfsadmin -safemode enter
#hdfs dfsadmin -saveNamespace
#hdfs dfsadmin -safemode leave

#hdfs fsck / > "$DB_BACKUP/fsck_before_stop_`date +%Y-%m-%d`"


typeset -r LogPath='/hadoop/patch/';

#sleep 2m
#------------------------#
typeset -r aLog="${LogPath}status_before__stop_$(date '+%Y%b%d')";

echo "----------------------------------------------------------------------------" > ${aLog};
echo "-------------------------Before stop All the service -----------------------" >> ${aLog};
echo "----------------------------------------------------------------------------" >> ${aLog};

curl -k -u admin:MercerH@doop2016 -X GET 'https://usdfw24as54:8080/api/v1/clusters/MMCHDP/services?fields=ServiceInfo/state'|grep "service_name" >> ${aLog};


echo "--------------------------------------------------------------------------" >> ${aLog};

systemctl status postgresql.service >> ${aLog};

echo "--------------------------------------------------------------------------" >> ${aLog};

ambari-server status >> ${aLog};

echo "--------------------------------------------------------------------------" >> ${aLog};

ambari-agent status >> ${aLog};

echo "--------------------------------------------------------------------------" >> ${aLog};

echo "--------------------------------------------------------------------------" >> ${aLog};
echo "-------------------------Stoping the ambari services----------------------" >> ${aLog};
echo "--------------------------------------------------------------------------" >> ${aLog};

curl -k -u admin:MercerH@doop2016 -i -H "X-Requested-By: ambari"  -X PUT -d '{"RequestInfo":{"context":"_PARSE_.STOP.ALL_SERVICES","operation_level":{"level":"CLUSTER","cluster_name":"MMCHDP"}},"Body":{"ServiceInfo":{"state":"INSTALLED"}}}' 'https://usdfw24as54:8080/api/v1/clusters/MMCHDP/services';

echo "--------------------------------------------------------------------------" >> ${aLog};

#sleep 5m

echo "--------------------------------------------------------------------------" >> ${aLog};
echo "-------------------------After stop the other service --------------------" >> ${aLog};
echo "--------------------------------------------------------------------------" >> ${aLog};
echo "--------------------------------------------------------------------------" >> ${aLog};

ambari-server stop >> ${aLog};
ambari-server status >> ${aLog};


echo "--------------------------------------------------------------------------" >> ${aLog};

ambari-agent stop >> ${aLog};
ambari-agent status >> ${aLog};

#sleep 1m
echo "--------------------------------------------------------------------------" >> ${aLog};

systemctl stop postgresql.service >> ${aLog};
systemctl status postgresql.service >> ${aLog};

echo "--------------------------------------------------------------------------" >> ${aLog};
echo "--------------------------------------------------------------------------" >> ${aLog};

systemctl status postgresql.service

#su /usr/pgsql-9.4/bin/pg_ctl  -D /var/lib/pgsql/9.4/data status
#systemctl stop postgresql.service
mailx -s "`date +'%b-%d-%Y'` HDP STOP" giri.nadarajah@mercer.com < ${aLog};
