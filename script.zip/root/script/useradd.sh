#!/bin/bash

kinit -kt /etc/security/keytabs/hdfs.headless.keytab hdfs-MMCHDP@CORP.MMCO.INT
read -p "Enter UserName : "  username
echo "Welcome $username!"

hdfs dfs -mkdir /user/$username
hdfs dfs -chown $username:$username /user/$username
echo $username > /root/newuser/$username.txt
ambari-server sync-ldap --users /root/newuser/$username.txt

