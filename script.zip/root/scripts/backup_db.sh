#!/bin/bash

## This is assumed to run as root since passwords are not used. 
## Variables in all upper case should or can be defined in 
## the config file


######  AVAILABLE OPTIONS

##############################
## Prefix for backup file names
#  BACKUP_PREFIX=lab_hdp.


##############################
##  mysql_dump databases (see mysql_dump --all-databases option)
#  ENABLE_DUMP_ALL_MYSQL_DB=yes

##############################
##  only mysql_dump these databases (space delimited)
#  MYSQLDB_LIST="hive ranger ranger_audit oozie"

##############################
## Setup Postgres databases to backup (space delimited)
#  PGDB_LIST="ambari"

##############################
## Dump file of only global objects (roles and tablespaces), no databases
#  ENABLE_PG_GLOBALS_BACKUPS=yes

##############################
## Dump the entire datasbase (pg_dumpall)
#  ENABLE_DUMP_ALL_PG_DB=yes

##############################
## (required) local destination directory 
#  LOCALDIR=/hadoop/backups

##############################
## Email results to these addresses
#  ADMINS=admin1@x.com,admin2@x.com  

##############################
## Maximuim backups to keep
#  MAX_COPIES_TO_KEEP=3

##############################
##HDFS backup config params
HDFS_USER=hdfs     #(required for copy2hdfs) 
HDFS_BACKUP_DIR=/backups/db #(required for copy2hdfs)
# HDFS_KRB_RENEW_CMD='kinit -kt /etc/security/keytabs/my.keytab PRINC@REALM.COM'  #(optional for copy2hdfs)
## Enabled and added the kinit for the hdfs user - MR - 04-Oct-2017
HDFS_KRB_RENEW_CMD='kinit -kt /etc/security/keytabs/hdfs.headless.keytab hdfs-MMCHDP@CORP.MMCO.INT'  #(optional for copy2hdfs)



##############################
##############################
##############################
##### FUNCTIONS
##############################

function usage() {
   echo "$*"
   echo "usage: `basename $0` <config_file>"
   echo "   This script will create backups of mysql and postgres databases"
   echo "   A configuration file is required."
   echo "   This script should run as root." 
   echo "   Read comments at the top of the script for config file options"
   exit 255
}


function report_status() {
    msg_out+="$1\n"
}

function report_error() {
    msg_out+="ERROR: $1\n"
    msg_errors+="ERROR: $1\n"
    exit_code=200
}

function copy_to_hdfs() {
   # Copies the file to HDFS.
   # Args: file     - file to be copied
   # Configs: 
   #     HDFS_USER          (required)
   #     HDFS_BACKUP_DIR    (required)
   #     HDFS_KRB_RENEW_CMD (optional)


   local l_file=$1

   ## HDFS PUT file
   #
   if [ "$HDFS_USER" != "" ];then 
      if [ "$HDFS_KRB_RENEW_CMD" != "" ];then
         ## RENEW Kerberos Ticket
         #su - $HDFS_USER $HDFS_KRB_RENEW_CMD
         $HDFS_KRB_RENEW_CMD
         [ $? -ne 0 ] && report_error "Failed to renew krb ticket."
      fi

      #echo "sudo -u $HDFS_USER hdfs dfs -mkdir -p $HDFS_BACKUP_DIR"
      #sudo -u $HDFS_USER hdfs dfs -mkdir -p $HDFS_BACKUP_DIR
      echo "hdfs dfs -mkdir -p $HDFS_BACKUP_DIR"
      hdfs dfs -mkdir -p $HDFS_BACKUP_DIR
      [ $? -ne 0 ] && report_error "Failed to mkdir to hdfs: $HDFS_BACKUP_DIR"

      cmd="hdfs dfs -put $l_file $HDFS_BACKUP_DIR/."

      if [ "$HDFS_BACKUP_DIR" != "" ];then
         report_status "   copying to hdfs ${HDFS_BACKUP_DIR}/$l_file"
         #sudo -u $HDFS_USER $cmd
         $cmd
         [ $? -ne 0 ] && report_error "Failed to copy file to hdfs: $cmd"
      fi
   fi
}


function create_backup() {

    local dbname_opt=$1

    local backup_name="${BACKUP_PREFIX}${g_db_type}.backup.${g_now}.${dbname_opt}.sql"
    local delete_name_pattern="${BACKUP_PREFIX}${g_db_type}.backup.*.${dbname_opt}.sql"

    echo "Backing up.....${backup_name}: $g_cmd"

    ## Execute the backup command and verify
    eval "$g_cmd > ${backup_name}"
    if [ $? -ne 0 ];then
         report_error "failed backup command for ${backup_name}: $g_cmd"
         return 1 #quit the function
      elif [ ! -s ${backup_name} ];then
         ## zero bytes of output
         report_error "failed to backup ${backup_name}. Zero length field: $g_cmd"
         return 1 #quit the function
    fi


    echo "Compressing backup.....${backup_name}.zip"

    # -s returns 0 if file is empty
    [ ! -s ${backup_name} ] && report_error "Missing or empty file ${backup_name}"

    zip ${backup_name}.zip ${backup_name}
    if [ $? -ne 0 ];then

         report_error "failed to zip backup ${backup_name}.zip\n"
    else

          [ -s ${backup_name}.zip ] && rm ${backup_name}
         filesize=`stat --printf="%s" ${backup_name}.zip`
         report_status "SUCCESS: backuped db $i to ${backup_name}.zip: $filesize bytes\n"
    fi


    copy_to_hdfs ${backup_name}.zip

    
    delete_oldest_backups "${delete_name_pattern}.zip" "."
}

function report_final_results() {

    [ "$msg_errors" != "" ] && msg_errors="-----ERRORS----\n$msg_errors"
    echo -e "$msg_errors\n\n-----SUMMARY----\n\n$msg_out"

    # SEND MAIL
    if [ "$ADMINS" != "" ];then
         [ $exit_code -ne 0 ] && g_subj="$g_subj - ERRORS"
         echo -e "$msg_errors\n\n-----SUMMARY----\n\n$msg_out" |mailx -s "$g_subj" $ADMINS
    fi
}


function backup_mysql() {
    g_db_type=MYSQL

    # Prepare destination directory
    [ ! -d $LOCALDIR ] && mkdir -p $LOCALDIR 
    cd $LOCALDIR

    if [ "${ENABLE_DUMP_ALL_MYSQL_DB}" = "yes" ];then
        echo "Dumping All MYSQL databases"
        g_cmd="mysqldump --all-databases"
        create_backup "all-databases"
    fi

    ## MYSQL databases
    for i in $MYSQLDB_LIST;do
        g_cmd="mysqldump $i "

        create_backup $i
    done

}

function backup_postgres() {
    g_db_type=POSTGRES

    # Prepare destination directory
    [ ! -d $LOCALDIR ] && mkdir -p $LOCALDIR 
    cd $LOCALDIR

    if [ "$ENABLE_DUMP_ALL_PG_DB" = "yes" ];then
        echo "Dumping all postgres databases"
        g_cmd="su - postgres -c 'pg_dumpall ' "
        create_backup "all-databases" 
    fi

    if [ "$ENABLE_PG_GLOBALS_BACKUPS" = "yes" ];then
        echo "Dumping postgres globals such as roles and tablespaces - no databases"
        g_cmd="su - postgres -c 'pg_dumpall -g' "
        create_backup "pg_globals" 
    fi

    ## PG/postgres individual databases
    for i in $PGDB_LIST;do
        g_cmd="su - postgres -c 'pg_dump $i' "

        create_backup $i
    done

}

function delete_oldest_backups() {
   local delete_name_pattern=$1
   local find_dir=$2  # base dir for find command

   if [ "${MAX_COPIES_TO_KEEP}" != "" ] && [ ${MAX_COPIES_TO_KEEP} -gt 0 ];then
      echo  "----------------------------------" 
      echo "Deleting oldest files [keep ${MAX_COPIES_TO_KEEP}]: ${delete_name_pattern}"
      old_files=`find ${find_dir} -type f \
           -name "${delete_name_pattern}" \
           -printf "%T+\t%p\n" \
           | sort \
           | awk '{print $2}' \
           | head -n -${MAX_COPIES_TO_KEEP} `
      
      echo -e "Deleting files: \n${old_files}"
      echo "${old_files}" | xargs -i rm -f {}
 
      echo  "----------------------------------" 
   fi
}

##############################
##### MAIN
##############################

## Check inputs
[ $# -ne 1 ] && usage "Missing config file: $*"
[ ! -f $1 ] &&  usage "config file does ojnt exist: $*"

report_status "Local backup dir: $LOCALDIR"

echo "##################################"
echo "## Beginning backups `date`"
echo "##################################"
echo "----------------------------------" 
## Initialize
config_file=$1
source ${config_file} #source the file so variables are available


exit_code=0
msg_out=""
g_now=`date +"%F.%H.%M.%S"`  # used in backup filenames


## Do backups
backup_mysql
backup_postgres


## Copy to HDFS - Added by MR - 04-Oct-2017
# copy_to_hdfs


# Finish and cleanup
report_final_results

exit $exit_code

