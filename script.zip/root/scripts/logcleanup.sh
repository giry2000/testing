sudo -u hdfs -i -n
kinit -kt /etc/security/keytabs/hdfs.headless.keytab hdfs-MMCHDP@CORP.MMCO.INT 

/usr/sbin/logrotate -s /var/log/logstatus logrotate.conf
hadoop fs -copyFromLocal /hadoop/log/hive/*.gz /backups/logs
hadoop fs -copyFromLocal /hadoop/log.orig/hive/*.gz /backups/logs
hadoop fs -copyFromLocal /hadoop/log/hadoop/hdfs/*.gz /backups/logs

if [ $? -ne 0 ]; then
## echo "Error in script"
mailx -s " Error in Log Rotation!!" magesh.ranganathan@mercer.com <<<$'\n Please check the log file for further details. \n'
else
rm -rf /hadoop/log/hive/*.gz /hadoop/log.orig/hive/*.gz /hadoop/log/hadoop/hdfs/*.gz
mailx -s " Log Rotation completed successfully!!" magesh.ranganathan@mercer.com <<<$' '
## mailx -s "Weekly Snapshot Backup completed successfully!!" magesh.ranganathan@mercer.com <<<$''
## echo "Script successful"
fi

