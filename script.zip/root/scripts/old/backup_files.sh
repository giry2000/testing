#!/bin/bash

## This script will Backup some of the local HDP and Ambari directories
## Variables in all CAPITAL letters are configuration vars.
## There are some config vars in the MAIN below

MAX_COPIES_TO_KEEP=3
LOCALDIR=/hadoop/backups/files
HDFS_USER=hdfs                 #(required for copy2hdfs)
HDFS_BACKUP_DIR=/backups/files #(required for copy2hdfs)


g_subj="Files backup"


function report_status() {
    msg_out+="$1\n"
}

function report_error() {
    msg_out+="ERROR: $1\n"
    msg_errors+="ERROR: $1\n"
    exit_code=200
}


function report_final_results() {

    [ "$msg_errors" != "" ] && msg_errors="-----ERRORS----\n$msg_errors"
    echo -e "$msg_errors\n\n-----SUMMARY----\n\n$msg_out"

    # SEND MAIL
    if [ "$ADMINS" != "" ];then
         [ $exit_code -ne 0 ] && g_subj="$g_subj - ERRORS"
         echo -e "$msg_errors\n\n-----SUMMARY----\n\n$msg_out" |mailx -s "$g_subj" $ADMINS
    fi
}



function delete_oldest_backups() {
   local delete_name_pattern=$1
   local find_dir=$2  # base dir for find command

   if [ "${MAX_COPIES_TO_KEEP}" != "" ] && [ ${MAX_COPIES_TO_KEEP} -gt 0 ];then
      echo "   Prep to delete oldest files [keep ${MAX_COPIES_TO_KEEP}]: [from ${find_dir}] matching ${delete_name_pattern}"
      old_files=`find ${find_dir} -type f \
           -name "${delete_name_pattern}" \
           -printf "%T+\t%p\n" \
           | sort \
           | awk '{print $2}' \
           | head -n -${MAX_COPIES_TO_KEEP} `

   
      if [ "${old_files}" != "" ];then 
         echo -e "   Deleting files: \n${old_files}"
         echo "${old_files}" | xargs -i rm -f {}
      else
         echo "   Nothing to delete"
      fi
   else
      echo "   Not deleting any backups. Variable is not set: MAX_COPIES_TO_KEEP"
   fi
}

function copy_to_hdfs() {
   # Copies the file to HDFS. 
   # Args: file     - file to be copied
   # Configs:
   #     HDFS_USER          (required)
   #     HDFS_BACKUP_DIR    (required)
   #     HDFS_KRB_RENEW_CMD (optional)


   local l_file=$1

   ## HDFS PUT file
   #
   if [ "$HDFS_USER" != "" ];then
      if [ "$HDFS_KRB_RENEW_CMD" != "" ];then
         ## RENEW Kerberos Ticket
         sudo -u $HDFS_USER $HDFS_KRB_RENEW_CMD
         [ $? -ne 0 ] && report_error "Failed to renew krb ticket."
      fi

      echo "sudo -u $HDFS_USER hdfs dfs -mkdir -p $HDFS_BACKUP_DIR"
      sudo -u $HDFS_USER hdfs dfs -mkdir -p $HDFS_BACKUP_DIR
      [ $? -ne 0 ] && report_error "Failed to mkdir to hdfs: $HDFS_BACKUP_DIR"

      cmd="hdfs dfs -put $l_file $HDFS_BACKUP_DIR/."

      if [ "$HDFS_BACKUP_DIR" != "" ];then
         report_status "   copying to hdfs ${HDFS_BACKUP_DIR}/$l_file"
         sudo -u $HDFS_USER $cmd
         [ $? -ne 0 ] && report_error "Failed to copy file to hdfs: $cmd"
      fi
   fi
}


function get_valid_dir_list() {
   local l_dir_list="$*"
   g_retval=""
   for i in ${l_dir_list};do
      if [ -f "$i" ] || [ -d "$i" ];then
         g_retval+=" $i"
      fi
   done
}

function create_file_backup() {
   local l_dir_list="$*" 

   if [ "$l_dir_list" != "" ];then
      echo  "----------------------------------"
      echo "Backing up [${BACKUP_PREFIX}] ${l_dir_list}"

      backup_name="${BACKUP_PREFIX}.BACKUP.${HOSTNAME}.${g_now}.tgz"
      delete_name_pattern="${BACKUP_PREFIX}.BACKUP.${HOSTNAME}.*.tgz"

      #Tar the file. Suppress the warning about removing leading /
      tar -czf ${backup_name} ${l_dir_list} 2>&1 |grep -v "tar: Removing leading \`/' from member names"
      if [ -f ${backup_name} ];then
         size=`ls -lh ${backup_name} |awk '{print $5}'`
         echo "Completed backup [$size bytes]: `pwd`/${backup_name}"
         report_status "Completed backup [$size bytes]: `pwd`/${backup_name}"
         copy_to_hdfs ${backup_name}
      else
         report_error "Failed to create backup: ${backup_name}"
      fi
      delete_oldest_backups "${delete_name_pattern}" "${LOCALDIR}"

   fi

}

###########################
###########################
###########################
#  MAIN
###########################
###########################



exit_code=0
g_now=`date +"%F.%H.%M.%S"`  # used in backup filenames

[ ! -d $LOCALDIR ] && mkdir -p $LOCALDIR
cd ${LOCALDIR}



report_status "Local backup dir: $LOCALDIR"
###########################
## HDP /etc/ config files
###########################

BACKUP_PREFIX=hdp_etc_dirs
BACKUP_DIRS="/etc/hadoop /etc/hbase /etc/hcatalog /etc/hive /etc/oozie /etc/sqoop /etc/zookeeper /etc/nifi"

get_valid_dir_list $BACKUP_DIRS
dir_list="${g_retval}"

create_file_backup "${dir_list}"

###########################
## Oozie DB /opt/oozie/ files
###########################

BACKUP_PREFIX=oozie_derby_db
BACKUP_DIRS="/opt/hadoop/oozie"

get_valid_dir_list $BACKUP_DIRS
dir_list="${g_retval}"

create_file_backup "${dir_list}"

###########################
## Ambari files
###########################

BACKUP_PREFIX=ambari_dirs
BACKUP_DIRS="/etc/ambari-server /etc/ambari-agent /var/lib/ambari-server/keys /var/lib/ambari-server/resources/stacks/HDPLocal /var/lib/ambari-agent/data"


get_valid_dir_list $BACKUP_DIRS
dir_list="${g_retval}"

create_file_backup "${dir_list}"

###########################
## Wrap it up 
###########################

# Finish and cleanup
report_final_results

exit $exit_code


