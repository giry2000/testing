#!/bin/bash


declare -a fileSystemDirectoryList=("/var/hdp/ranger/" "/var/hdp/log/zeppelin/" "/var/hdp/log/oozie" "/var/hdp/log/hbase/" "/var/hdp/log/atlas/" "/var/hdp/kafka" "/var/hdp/yarn/" "/var/hdp/ambari-metrics-collector/" "/var/log/ranger/" "/var/log/das/")

for i in "${fileSystemDirectoryList[@]}"
do
    echo "Cleaning up $i ..."

    find ${i} -type f -mtime +90 -exec rm -rf {} \;
done

