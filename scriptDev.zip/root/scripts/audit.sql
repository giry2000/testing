SELECT u.login_id
       ,l.sess_id
    ,DATE_SUB(l.create_time, INTERVAL 5 HOUR) "Logging_Time (Eastern)"
       ,l.create_time
       ,l.update_time
       ,l.class_type
       ,case class_type 
   when 1030  then "Ranger Policy"
   when 1003  then "Ranger User"
   when 2     then "User profile"
   when 1002  then "Ranger Group"
   when 1020  then "Ranger Service"
   when 7     then "Password Change"
   else "Audit Type not mapped - Check with Hadoop Admin"
    end  Audit_Type
       ,l.action
    ,l.parent_object_name
       ,l.object_name
       ,l.prev_val
       ,l.new_val
       -- ,l.* 
FROM ranger_db.vx_trx_log l
     LEFT JOIN ranger_db.x_portal_user u
      ON  l.added_by_id = u.id
order by l.create_time desc;

