#!/bin/bash


sh /root/scripts/pre-check.sh;

typeset -r LogPath='/hadoop/logs/patch/';

#------------------------#
typeset -r aLog="${LogPath}After_Service_start_status_$(date '+%Y%b%d')";

echo "--------------------------------------------------------------------------" > ${aLog};
echo "-------------------------After start the service --------------------------" >> ${aLog};
echo "--------------------------------------------------------------------------" >> ${aLog};

echo "--------------------------------------------------------------------------" >> ${aLog};
sleep 1m

systemctl status postgresql.service >> ${aLog};

mkdir -p /var/run/postgresql
chown postgres:postgres /var/run/postgresql

systemctl start postgresql.service

systemctl status postgresql.service >> ${aLog};

echo "--------------------------------------------------------------------------" >> ${aLog};

systemctl status mysql.service >> ${aLog};

mkdir -p /var/run/mysqld/
chown mysql:mysql -R /var/run/mysqld
chmod 775 -R /var/run/mysqld

echo "--------------------------------------------------------------------------" >> ${aLog};

#ambari-agent start 
ambari-agent status  >> ${aLog};

echo "--------------------------------------------------------------------------" >> ${aLog};
sleep 2m

systemctl status mysql.service >> ${aLog};

