kinit -kt /etc/security/keytabs/hdfs.headless.keytab hdfs-mmchdpdev@CORP.MMCO.INT
