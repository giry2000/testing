#!/bin/env ksh
# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
# Author       : Giry Nadarajah
# Last updated : Feb/14/2020
# synopsis     : Hadoop HDFS Snapshots
# Dependency   : None
# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
#
# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
# @@@ CONFIGURABLE GLOBAL PARAMETERS @@@
# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
#
#-------------------------
# location of executables
#-------------------------
typeset -r EXE='/bin';
typeset -r USR='/usr/bin';
#
#----------------------------
# locaton of the scripts log
#----------------------------
#typeset -r Log="/hadoop/backups/hdpadmin/scripts/$(${EXE}/basename $0).$(${EXE}/date '+%d%b%Y.%H%M%S').log";
typeset -r Log="/tmp/hdp/hdfs_snap_log/$(${EXE}/basename $0).$(${EXE}/date '+%d%b%Y.%H%M%S').log";
#
#------------------------------------------------------
# Maximum size of email body, in bytes, can be attached
#------------------------------------------------------
typeset -r -i MAX_Body_Size=1024000;
#
#-------------------------------------------------------
# Number of days of aged snapshots to be deleteSnapshot
#-------------------------------------------------------
typeset -r -i Delete_Snapshots_Older_Than=1;
#
#-------------------------------------
# Absolute path to warehouse directory
#-------------------------------------
#nap.sht -r Warehouse_DIR='/dev/datalake/enterprise';
 Warehouse_DIR='/dev/datalake/enterprise';
#
#---------------------------
# Array of Snapshottable dbs
#---------------------------
set -A DBS adobe aigh allegro allocadia allocadia atlas datascience datascience_model_results dev dev_career_gst dev_gst dev_mdcsurvey ebx gbm gbm_clienthub gpos gst intellify kava marketo mdcsurvey mercer mercerforce mideas pendo webcas 
#cust_bill.db cust_cust.db cust_intractn.db cust_measure.db cust_ord.db \
#
#
# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
# @@@ PLEASE DO NOT CHANGE ANYTHING BELOW THIS POINT @@@
# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
#
#--------------
# Today's date
#--------------
typeset -r Today="$(${EXE}/date '+%Y-%m-%d')";
#
#---------------
# Day in seconds
#---------------
typeset -i TodayInSeconds="$(${EXE}/date '+%s')";
#
#----------
# Timestamp
#----------
#typeset -r Timestamp="$(${EXE}/echo [\$(${EXE}/date)])";
#
# Trap the signals
#-----------------
trap 'doCleanups' 0 1 2 3 15;
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# write a startup message to Log
#--------------------------------
${USR}/printf "\n$(eval ${Timestamp}) [Startup...] [Daily Snapshots]\n" | ${USR}/tee ${Log};
# 
# Kinit
#------
kinit -kt /etc/security/keytabs/hdfs.headless.keytab hdfs-mmchdpdev@CORP.MMCO.INT 1>> ${Log} 2>&1;
if [[ ${?} -ne 0 ]]
then
	${USR}/printf "\n$(eval ${Timestamp}) [Erroed...In Kinit]\n" | ${USR}/tee -a ${Log};
	exit 1;
fi
doCleanups()
{
       EMailSize=$(${EXE}/ls -l ${Log} | ${EXE}/awk '{print $5}');
       if [[ ${EMailSize} -gt ${MAX_Body_Size} ]]
       then
               ${USR}/printf "\n$(eval ${Timestamp}) [No Emailing...] [Too Big EmailBody -> ${EMailSize} Bytes] [Max EmailBody -> ${MAX_Body_Size} Bytes\n" | ${USR}/tee -a ${Log};
       else
               ${EXE}/cat "${Log}" | ${EXE}/mailx -s "(*** Weekly Job : Done *** ) (Status : Embedded EmailBody)" giri.nadarajah@mercer.com, Justin.Ng@mercer.com 1>> ${Log} 2>&1;
               ${USR}/printf "\n$(eval ${Timestamp}) [Emailing...Done]\n" | ${USR}/tee -a ${Log};
       fi
}

#
# Check if deletion of aged snapshots is required
#-------------------------------------------------
for eachDB in "${DBS[@]}"
do
	# AllowSnapshot
	#--------------
        ${USR}/printf "\n\n$(eval ${Timestamp}) [db...] [Name -> ${eachDB}]\n +++++++\n" | ${USR}/tee -a ${Log};
        ${USR}/printf "\n$(eval ${Timestamp}) [db...] [Snapshots Name -> ${Warehouse_DIR}/${eachDB}]\n" | ${USR}/tee -a ${Log};
	${USR}/printf "\n$(eval ${Timestamp}) [AllowSnapshot...] [Snapshots Name -> ${Warehouse_DIR}/${eachDB}]\n" | ${USR}/tee -a ${Log};
	hdfs dfsadmin -allowSnapshot ${Warehouse_DIR}/${eachDB} 1>> ${Log} 2>&1;
	if [[ ${?} -ne 0 ]]
	then
		${USR}/printf "\n$(eval ${Timestamp}) [Erroed...In AllowSnapshot] [Snapshots Name -> ${Warehouse_DIR}/${eachDB}]\n" | ${USR}/tee -a ${Log};
		exit 1;
        fi
        #cleanup and deletion
        #--------------------- 
        hdfs dfs -test -e "${Warehouse_DIR}/${eachDB}/.snapshot"; 
        if [[ ${?} -eq 0 ]]
	then
		hdfs dfs -ls -d "${Warehouse_DIR}/${eachDB}/.snapshot/*" 2>> ${Log} | while read eachSnapshot
		do
			#check age of snapshot
			#----------------------
			snapshotName=$(${EXE}/echo ${eachSnapshot} | ${EXE}/awk '{print $8}');
			snapshotDate=$(${EXE}/echo ${eachSnapshot} | ${EXE}/awk '{print $6}');
			# Calculate Days Difference
			#---------------------------
			difference=$(( ( ${TodayInSeconds} - $(${EXE}/date -d "${snapshotDate}" +%s) ) / (24 * 60 * 60) ));
			# log snapshotName, difference and snapshotDate
			#-----------------------------------
			${USR}/printf "\n$(eval ${Timestamp}) [Checking...] [Snapshots Name -> ${snapshotName}] [Snapshot Date -> ${snapshotDate}] ";
			${USR}/printf "[Snapshot Age -> ${difference} Days]\n" | ${USR}/tee -a ${Log};
			# check if deletion is required
			#-------------------------------
			if [[ ${difference} -gt ${Delete_Snapshots_Older_Than} ]]
			then
				#deleting snapshot
				#-----------------
				hdfs dfs -deleteSnapshot ${Warehouse_DIR}/${eachDB} ${snapshotDate} 1>> ${Log} 2>&1;
				if [[ ${?} -eq 0 ]]
				then
				  ${USR}/printf "\n$(eval ${Timestamp}) [Deleted...] [Snapshots Name -> ${Warehouse_DIR}/${eachDB} ${snapshotDate}]\n" | ${USR}/tee -a ${Log};
				else
				  ${USR}/printf "\n$(eval ${Timestamp}) [Errored...In Deletion] [Snapshots Name -> ${Warehouse_DIR}/${eachDB} ${snapshotDate}]" | ${USR}/tee -a ${Log};
				fi
                        fi
		done
         fi
         #create snaphost
         #---------------
         hdfs dfs -createSnapshot ${Warehouse_DIR}/${eachDB} ${Today} 1>> ${Log} 2>&1;
         if [[ ${?} -eq 0 ]]    
         then
                ${USR}/printf "\n$(eval ${Timestamp}) [Created...] [Snapshot -> ${Warehouse_DIR}/${eachDB}/.snapshot/${Today}]\n" | ${USR}/tee -a ${Log};
         else
                ${USR}/printf "\n$(eval ${Timestamp}) [Errored...In Creation] [Snapshot -> ${Warehouse_DIR}/${eachDB}/.snapshot/${Today}]" | ${USR}/tee -a ${Log};
         fi

####COPY TO SAN #######

#hdfs dfs -copyToLocal ${Warehouse_DIR}/${eachDB}/.snapshot/${Today} /mnt/hdfs_backup/dev/${eachDB}/;

done

