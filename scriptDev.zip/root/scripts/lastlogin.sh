#!/bin/env ksh
#-------------

#echo  "$(hostname -f) : $(last)"  > /hadoop/last_login/lastlogin1.log;
#head /hadoop/last_login/lastlogin1.log > /hadoop/last_login/lastlogin.log
#last  -w |grep "`date +'%a %b %Oe'`" |sort -k 7n > /hadoop/last_login/lastlogin.log
last -w |tac > /hadoop/last_login/lastlogin.log
