#!/bin/bash

declare -a fileSystemDirectoryList=("/var/hdp/ranger/admin/")

for i in "${fileSystemDirectoryList[@]}"
do
    echo "Cleaning up $i ..."

    find ${i} -type f -mtime +90 -exec ls -ltr {} \;
done

