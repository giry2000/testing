#!/bin/bash
mysql -u root </root/scripts/audit.sql |tac > /hadoop/logs/ranger_audit/ranger_audit.csv

cp /hadoop/logs/ranger_audit/ranger_audit.csv  /hadoop/logs/ranger_audit/ranger_audit_`date '+%d%b%Y'`.csv

#sed -i '$ d' /hadoop/logs/ranger_audit/ranger_audit_`date '+%d%b%Y'`.csv > /hadoop/logs/ranger_audit/ranger_audit.csv
sed -i '$ d'  /hadoop/logs/ranger_audit/ranger_audit.csv

