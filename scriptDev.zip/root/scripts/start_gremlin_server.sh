/root/scripts/hdfs_kinit.sh
service gremlin-server restart
