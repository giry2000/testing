#!/bin/bash

kinit -kt /etc/security/keytabs/svc-kfbatch.kt svc-kfbatch@CORP.MMCO.INT

declare -a HDFSDirectoryList=("/spark2-history" "/user/svc-kfbatch/.staging")

for i in "${HDFSDirectoryList[@]}"
do
    echo "Cleaning up $i ..."
    fileList=`hdfs dfs -ls $i | tr -s " " | cut -d' ' -f6-8 | grep "^[0-9]" | awk 'BEGIN{ MIN=24*60*90; LAST=60*MIN; "date +%s" | getline NOW } { cmd="date -d'\''"$1" "$2"'\'' +%s"; cmd | getline WHEN; DIFF=NOW-WHEN; if(DIFF > LAST){ print $3 }}'`

    echo ${fileList}
done

declare -a fileSystemDirectoryList=("/var/log/oozie/")

for i in "${fileSystemDirectoryList[@]}"
do
    echo "Cleaning up $i ..."

    find ${i} -type f -mtime +90 -exec ls -ltr {} \;
done

